#ifndef DEFINES_H_
#define DEFINES_H_

#include "ap_int.h"
#include "ap_fixed.h"
#include "nnet_utils/nnet_types.h"
#include <cstddef>
#include <cstdio>

//hls-fpga-machine-learning insert numbers
#define N_INPUT_1_1 48
#define N_INPUT_2_1 48
#define N_INPUT_3_1 1
#define OUT_HEIGHT_2 46
#define OUT_WIDTH_2 46
#define N_FILT_2 6
#define OUT_HEIGHT_5 11
#define OUT_WIDTH_5 11
#define N_FILT_5 6
#define OUT_HEIGHT_6 9
#define OUT_WIDTH_6 9
#define N_FILT_6 8
#define OUT_HEIGHT_9 4
#define OUT_WIDTH_9 4
#define N_FILT_9 8
#define OUT_HEIGHT_10 2
#define OUT_WIDTH_10 2
#define N_FILT_10 10
#define OUT_HEIGHT_13 1
#define OUT_WIDTH_13 1
#define N_FILT_13 10
#define N_SIZE_1_14 10
#define N_LAYER_15 15
#define N_LAYER_18 10
#define N_LAYER_21 5

//hls-fpga-machine-learning insert layer-precision
typedef ap_fixed<16,6> model_default_t;
typedef nnet::array<ap_ufixed<8,0>, 1*1> input_t;
typedef nnet::array<ap_fixed<8,2>, 6*1> layer2_t;
typedef ap_fixed<8,1> weight2_t;
typedef ap_fixed<8,1> bias2_t;
typedef nnet::array<ap_fixed<16,6>, 6*1> layer3_t;
typedef nnet::array<ap_ufixed<8,2>, 6*1> layer4_t;
typedef nnet::array<ap_ufixed<8,2>, 6*1> layer5_t;
typedef nnet::array<ap_fixed<8,2>, 8*1> layer6_t;
typedef ap_fixed<8,3> weight6_t;
typedef ap_fixed<8,3> bias6_t;
typedef nnet::array<ap_fixed<16,6>, 8*1> layer7_t;
typedef nnet::array<ap_ufixed<8,2>, 8*1> layer8_t;
typedef nnet::array<ap_ufixed<8,2>, 8*1> layer9_t;
typedef nnet::array<ap_fixed<8,2>, 10*1> layer10_t;
typedef ap_fixed<8,3> weight10_t;
typedef ap_fixed<8,3> bias10_t;
typedef nnet::array<ap_fixed<16,6>, 10*1> layer11_t;
typedef nnet::array<ap_ufixed<8,2>, 10*1> layer12_t;
typedef nnet::array<ap_ufixed<8,2>, 10*1> layer13_t;
typedef nnet::array<ap_fixed<8,2>, 15*1> layer15_t;
typedef ap_fixed<8,3> weight15_t;
typedef ap_fixed<8,3> bias15_t;
typedef nnet::array<ap_fixed<16,6>, 15*1> layer16_t;
typedef nnet::array<ap_ufixed<8,2>, 15*1> layer17_t;
typedef nnet::array<ap_fixed<8,2>, 10*1> layer18_t;
typedef ap_fixed<8,3> weight18_t;
typedef ap_fixed<8,3> bias18_t;
typedef nnet::array<ap_fixed<16,6>, 10*1> layer19_t;
typedef nnet::array<ap_ufixed<8,2>, 10*1> layer20_t;
typedef nnet::array<ap_fixed<8,2>, 5*1> layer21_t;
typedef ap_fixed<8,3> weight21_t;
typedef ap_fixed<8,3> bias21_t;
typedef nnet::array<ap_fixed<16,6>, 5*1> result_t;

#endif
